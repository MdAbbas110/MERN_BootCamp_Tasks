import { add , subtract} from './calculator.js'

const result1 = add(35,67)
console.log(result2);

const result2 = subtract(45,23)
console.log(result2);